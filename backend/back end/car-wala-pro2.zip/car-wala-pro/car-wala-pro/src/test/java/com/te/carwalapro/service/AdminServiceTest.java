package com.te.carwalapro.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AdminServiceTest {

	@Test
	void testRegData() {
		fail("Not yet implemented");
	}

	@Test
	void testGetData() {
		fail("Not yet implemented");
	}

	@Test
	void testLoginData() {
		fail("Not yet implemented");
	}

	@Test
	void testLoadUserByUsername() {
		fail("Not yet implemented");
	}

	@Test
	void testGetData1() {
		fail("Not yet implemented");
	}

	@Test
	void testGetAdminId() {
		fail("Not yet implemented");
	}

}
