package com.te.carwalapro.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CardetailsServiceTest {

	@Test
	void testInsertData() {
		fail("Not yet implemented");
	}

	@Test
	void testRemoveData() {
		fail("Not yet implemented");
	}

	@Test
	void testUpdateData() {
		fail("Not yet implemented");
	}

	@Test
	void testGetData2String() {
		fail("Not yet implemented");
	}

	@Test
	void testGetData1() {
		fail("Not yet implemented");
	}

	@Test
	void testGetData2Int() {
		fail("Not yet implemented");
	}

	@Test
	void testGetData3() {
		fail("Not yet implemented");
	}

	@Test
	void testGetCars() {
		fail("Not yet implemented");
	}

}
