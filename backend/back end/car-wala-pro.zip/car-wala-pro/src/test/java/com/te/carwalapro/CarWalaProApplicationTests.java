package com.te.carwalapro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarWalaProApplicationTests {

	@Test
	void contextLoads() {
	}

}
